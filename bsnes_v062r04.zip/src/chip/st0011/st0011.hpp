class ST0011 {
public:
  void init();
  void enable();
  void power();
  void reset();
};

extern ST0011 st0011;
