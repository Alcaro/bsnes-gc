rm -r libco
rm -r nall
rm -r ruby

cp -r ../../../libco ./libco
cp -r ../../../nall ./nall
cp -r ../../../ruby ./ruby

rm -r libco/doc
rm -r libco/test
