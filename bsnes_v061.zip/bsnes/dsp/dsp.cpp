#include <../base.hpp>

#define DSP_CPP
namespace SNES {

#if defined(DEBUGGER)
  #include "dsp-debugger.cpp"
#endif

}
