#include <../base.hpp>

#define ST0011_CPP
namespace SNES {

ST0011 st0011;

void ST0011::init() {
}

void ST0011::enable() {
}

void ST0011::power() {
}

void ST0011::reset() {
}

};
