#ifdef ST0010_CPP

void ST0010::serialize(serializer &s) {
  s.array(ram);
}

#endif
