rm -r nall
cp -r ../nall ./nall
